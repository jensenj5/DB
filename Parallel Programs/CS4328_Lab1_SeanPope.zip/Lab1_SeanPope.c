/* Name: Sean Pope
 * Date: 7/15/13
 * Assignment: Lab 1
 * Lab1_SeanPope.c
 * A program that sends an integer x from process 0 to 1,
 * then broadcasts that value to all other processes and prints it from process 2.
 * Process 0 will find (and print) the sum of the ranks of all processes.
 */
#include <stdio.h>
#include <string.h>
#include "mpi.h"

int main(int argc, char* argv[])
{
	int errs = 0;
	MPI_Status  status;			// Return status for value received
	int process_rank;			// Rank of the process
	int source;				// Source of data to receive
	int destination;			// Destination of data to send
	int tag = 0;				// Tag for messages
	int process_sum;			// Holds the value of the sum of all process ranks
	
	MPI_Init(&argc, &argv); // Start up MPI
	MPI_Comm_rank(MPI_COMM_WORLD, &process_rank); // Find process rank
	MPI_Reduce(&process_rank, &process_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD); // Sum the value of all process ranks

	if (process_rank == 0) // In process 0, send value x to process 1 and compute and output sum of all process ranks
	{
		int x = 9;
		destination = 1;
		printf("Sending value %i to process 1 from process %i.\n", x, process_rank);
		MPI_Send(&x, 1, MPI_INT, destination, tag, MPI_COMM_WORLD);

		printf("The sum of the ranks of all processes is %i.\n", process_sum);
	}
	if (process_rank == 1) // In process 1, receive a value x and broadcast it to all other processes
	{
		int x;
		source = 0;
		MPI_Recv(&x, 1, MPI_INT, source, tag, MPI_COMM_WORLD, &status);
		
		source = 1;
		printf("Broadcasting value %i to all processes from process %i.\n", x, process_rank);
		MPI_Bcast(&x, 1, MPI_INT, source, MPI_COMM_WORLD);
	}
	if(process_rank == 2) // In process 2, read broadcast and output value
	{
		int x;
		source = 1;
		MPI_Bcast(&x, 1, MPI_INT, source, MPI_COMM_WORLD);
		printf("The value received in process %i from broadcast is %i.\n", process_rank, x);
	}
	
	MPI_Finalize(); // Shut down MPI
	
	return errs;
}
